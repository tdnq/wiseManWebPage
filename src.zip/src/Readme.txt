/enNa
 /./epxplore
   --archive-all.html //同一类型所有课程
   --archive.html //同一类型部分课程
   --index.html //探索全部课程
   --paly.html //学习界面
   --single.html //单个课程介绍
 /./index
   --index.html //嗯呐首页
 /./student
   --personnal.html //学生个人页