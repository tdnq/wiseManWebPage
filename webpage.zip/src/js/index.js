$(document).ready(function(){

    $(".nav-item").on('click',function(){
        var index=$(this).index();
        console.log(index);
        
    })
});