/src
 
 #官网展示部分
  /less                       //css编写文件
  /css                        //less输出文件
  /iframe                     //开发依赖框架
  /fonts                      //官网需要的图片
  /font_1298383_c2agcfaxaaj   //图标字体

  /aboutUs.html               //官网--关于我们页面
  /contactUse.html            //官网--联系我们页面
  /index.html                 //官网首页

#嗯呐部分
  /enNa
  
  /./academicExchange
    --index.html              //学术交流页面

  /./enterprise
    --index.html              //企业端首页

  /./epxplore
    --archive-all.html        //同一类型所有课程
    --archive.html            //同一类型部分课程
    --index.html              //探索全部课程
    --paly.html               //学习界面
    --single.html             //单个课程介绍

  /fonts                      //嗯呐部分所需图片

  /./index
    --index.html              //嗯呐首页

  /./partner                  //合作伙伴
    --enterprises.html         //合作企业
    --single-enterprise.html  //单个企业展示
    --shools.html             //合作学校
    --single-shool.html       //单个合作学校

  /./practice                   
    --index.html              //所有实习信息展示
    --practice-single.html    //某个具体实习信息

  /./public                   //公用资源 主要包括“头尾样式”和一些“基础样式”

  /./student                  
    --personnal.html          //学生个人页

  /./teacher
   --index.html               //教师个人页

  /./student
    --personnal.html          //学生个人页


  总体情况： js部分和样式还会增改，需要进行二次迭代；
            官网展示可自适应，嗯呐偏功能，暂时固定在996px;
  